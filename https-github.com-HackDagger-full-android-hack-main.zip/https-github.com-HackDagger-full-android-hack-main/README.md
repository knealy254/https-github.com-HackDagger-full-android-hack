
![Banner](/banner.png?raw=true "title")



# Full Android Hack

Full Android Hack Malware



## Features

- 🔴 Real time
- 🌐 custom web view
- ✉️ receive all target message
- ✉️ send sms with target device to any number
- ✉️ recive all target contacts
- 💻 receive list of all installedd apps in target device
- 📁 receive any file or folder from target device
- 📁 delete any file or folder from target device
- 📷 capture main and front camera
- 🎙 capture microphone
- 📋 receive last clipboard text
- ✅️ auto start after device boot
- 🤖 Undetectable by antivirus


## How it works ?

all you have to do is create telegram bot and receive your token and replace it in app then send app to target and you will receive target sms every time somone send sms to target.
then you have full controll of target phone and you can manage it in telegram bot



## How to use ?

to get file and deployment check our telegram channel : [TELEGRAM CHANNEL](https://t.me/HackDagger)




